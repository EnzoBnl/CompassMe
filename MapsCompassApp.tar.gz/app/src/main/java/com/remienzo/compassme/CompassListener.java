package com.remienzo.compassme;

public interface CompassListener {
    void onNewBearing(float bearing);
}