package com.remienzo.compassme;

/*
Permet de faire remonter facilement un pas vers MainActivity pour l'affichage
 */
public interface StepListener {
    void stepOccurred();
}
